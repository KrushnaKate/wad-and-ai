const dbConnect = require("./mongo");
const express = require("express");
const app = express();
app.use(express.json());

//get API
app.get("/getData", async (req, res) => {
  let result = await dbConnect();
  result = await result.find().toArray();
  res.send(result);
});

//post API
app.post("/insertData", async (req, res) => {
  let result = await dbConnect();
  result = await result.insertOne(req.body);
  res.send("Data is inserted successfully.");
});

//put API
app.put("/updataData/:name", async (req, res) => {
  let result = await dbConnect();
  result = await result.updateOne(
    { name: req.params.name },
    { $set: req.body }
  );
  res.send("Data is updated successfully.");
});

app.delete("/deleteData/:name", async (req, res) => {
  let result = await dbConnect();
  result = await result.deleteOne({ name: req.params.name });
  res.send("Data is deleted successfully.");
});

app.listen(3000);
